import ObjectArraySample from "./ObjectArraySample";
import Part1 from "./Part1";


function App() {

  return (

    <>
    <Part1></Part1>
    <ObjectArraySample></ObjectArraySample>
    </>
  );
}

export default App;
